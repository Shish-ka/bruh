<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Application;

class ApplicationController extends Controller
{
//     /**
//      * Display a listing of the resource.
//      */
    public function index()
    {
        if(auth()->user()->role=='operator'){
            return Application::all();
        }
        return Application::where('user_id', auth()->user()->id)->get()->all(); //'user_id', auth()->user()->id
    }

//     /**
//      * Show the form for creating a new resource.
//      */
//     public function create()
//     {
//         //
//     }

//     /**
//      * Store a newly created resource in storage.
//      */
   public function store(Request $request)
    {
        if ($request->user()->role!=='operator') { 
            return response()->json([
                'message' => 'Доступ запрещён: только администратор может создавать категории.'
            ], 403);
        }
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'text' => 'required',
            'category_id' => 'required|exists:categories,id'

        ]);
        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }
        $application = Application::create(
            ['user-id' => $request->user()->id] + $validator->validated()
        );

        return response()->json([
            'id' => $application->id,
            'name' => $application->name,  
            'text' => $application->text, 
            'status' => $application->status,
            'category' => $application->category->name

        ]);
    }

//     /**
//      * Display the specified resource.
//      */
//     public function show(Category $category)
//     {
//         return $category;
//     }

//     /**
//      * Show the form for editing the specified resource.
//      */
//     public function edit(Category $category)
//     {
//         //
//     }

//     /**
//      * Update the specified resource in storage.
//      */
//     public function update(Request $request, Category $category)
//     {
//         if ($request->user()->role!=='operator') { 
//             return response()->json([
//                 'message' => 'Доступ запрещён: только администратор может создавать категории.'
//             ], 403);
//         }
//         $validator = Validator::make($request->all(), [
//             'name' => 'required|string|max:100|unique:categories,name'
//         ], [
//             'name.required' => 'Имя категории обязательно.',
//             'name.unique' => 'Категория с таким именем уже существует.',
//         ]);
//         if ($validator->fails()) {
//             return response()->json([
//                 'errors' => $validator->errors()
//             ], 422);
//         }
//         $category -> update([
//             'name'=>$request->input('name')
//         ]);

//         return response()->json([
//             'category' => $category
//         ], 201);
//     }

//     /**
//      * Remove the specified resource from storage.
//      */
//     public function destroy(Category $category)
//     {
//         $category->delete();
//     }
}
