<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Application extends Model
{
    protected $fillable = [
        'name',
        'text',
        'category_id',
        'user_id',
        'status'
    ];
}
