<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\ApplicationResource;

class TicketController extends Controller
{

    public function index()
    {
        if(auth()->user()->role == 'operator'){
            return Ticket::all();
        }else{
            return Ticket::where('user_id',auth()->user()->id)->get();
        }
    }

    public function create()
    {
        //
    }

   public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:100|unique:tickets,name'
        ], [
            'name.required' => 'Имя категории обязательно.',
            'name.unique' => 'Заявка с таким именем уже существует.',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }
        $ticket = Ticket::create([
            'name' => $request->input('name'),
            'text' => $request->input('text'),
            'category_id' => $request->input('category_id'),
            'user_id'=>$request->user()->id,
            'status'=>'Создана'
        ]);
        return new ApplicationResource($ticket);
    }

    public function show(Request $request,Ticket $ticket)
    {
        if($request->user()->role!=='operator' & $request->user()->id!==$ticket->user_id){
            return response()->json(['message'=>'Доступ ограничен'],403);
        }

        return new ApplicationResource($ticket);
    }

    public function update(Request $request, Ticket $ticket)
    {
        if($request->user()->role!=='operator'){
            return response()->json(['message'=>'Доступ ограничен'],403);
        }
        $validator = Validator::make($request->all(), [
            'status' => 'string'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }
        $ticket -> update([
            'status'=>$request->input('status')
        ]);
        return new ApplicationResource($ticket);
        
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Ticket $ticket)
    {
        if(auth()->user()->id !== $ticket->user_id){
            return response()->json(['message'=>'Доступ ограничен'],403);
        }
        $ticket->delete();
    }
}
