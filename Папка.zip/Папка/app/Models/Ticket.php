<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    /** @use HasFactory<\Database\Factories\TicketFactory> */
    use HasFactory;

    protected $fillable = [
        'name',
        'text',
        'category_id',
        'user_id',
        'status'
    ];
    public $timestamps = false;
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

}
