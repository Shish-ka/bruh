<?php

use Illuminate\Http\Request;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\TicketController;
use Illuminate\Support\Facades\Route;

Route::get('/users', [UserController::class, 'index']);
Route::post('/login', [UserController::class, 'login']);
Route::post('/signup', [UserController::class, 'signup']);


Route::middleware('auth:sanctum')->group(function () {
    Route::get('/categories', [CategoryController::class, 'index']);
    Route::post('/categories', [CategoryController::class, 'store']);
    Route::get('/categories/{category}', [CategoryController::class, 'show']);
    Route::patch('/categories/{category}', [CategoryController::class, 'update']);
    Route::delete('/categories/{category}', [CategoryController::class, 'destroy']);
    Route::get('/applications', [TicketController::class, 'index']);
    Route::post('/applications', [TicketController::class, 'store']);
    Route::get('/applications/{ticket}', [TicketController::class, 'show']);
    Route::patch('/applications/{ticket}', [TicketController::class, 'update']);
    Route::delete('/applications/{ticket}', [TicketController::class, 'destroy']);
});